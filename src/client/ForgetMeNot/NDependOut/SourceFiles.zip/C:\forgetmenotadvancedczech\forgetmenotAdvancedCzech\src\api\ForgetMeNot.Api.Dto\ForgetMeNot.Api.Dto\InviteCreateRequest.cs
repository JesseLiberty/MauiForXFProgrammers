﻿namespace ForgetMeNot.Api.Dto
{
    public class InviteCreateRequest
    {
        public string InvitedUserName { get; set; }
        public string InvitedUserCustomMessage { get; set; }
    }
}
