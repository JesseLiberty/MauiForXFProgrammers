﻿namespace ForgetMeNot.Api.Domain
{
    public class UserPreference
    {
        public string PreferencePrompt { get; set; }

        public string PreferenceValue { get; set; }
    }
}
