﻿namespace ForgetMeNot.Api.Domain
{
    public static class Roles
    {
        public static string Admin = "admin";
        public static string User = "user";
    }
}
