﻿namespace ForgetMeNot.Api.Dto
{
    public class UserUpdateRequest
    {
        public int Id { get; set; }
        public string FullName { get; set; }
        public string Email { get; set; }
    }
}
