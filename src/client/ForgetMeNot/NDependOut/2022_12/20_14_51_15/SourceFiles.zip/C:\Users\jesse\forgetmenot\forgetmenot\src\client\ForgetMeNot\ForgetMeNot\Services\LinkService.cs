﻿namespace ForgetMeNot.Services
{
    public  static partial class LinkService
    {
        public static string GetUri()
        {
            return "https://jesseliberty.com";
        }
    }
}
